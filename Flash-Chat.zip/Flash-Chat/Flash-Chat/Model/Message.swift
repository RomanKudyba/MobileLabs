//
//  Message.swift
//  Flash-Chat
//
//  Created by Роман К on 3/20/19.
//  Copyright © 2019 Роман К. All rights reserved.
//

class Message {
    
    var messageBody = ""
    var sender = ""
    
}

